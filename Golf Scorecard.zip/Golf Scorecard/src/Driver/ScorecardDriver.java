package Driver;

/**
 * Caleb Burns - cdburns1
 * CIS171 21708-25949
 * Apr 29, 2024
 */
public class ScorecardDriver {
	public static void main(String[] args) {
		// Start GUI
		view.ScorecardStarter.main(args);
		
	}
}
